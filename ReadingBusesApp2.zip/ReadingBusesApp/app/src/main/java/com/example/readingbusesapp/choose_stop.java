package com.example.readingbusesapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;

public class choose_stop extends AppCompatActivity {
    ListView lv;
    String[] stops = {"Reading Station","Highcroft Kenels","Winning Hand PH", "Ledbury Drive","The Green","Russell Street"};

    public static final String EXTRA_TEXT = "hi";
    private ArrayAdapter adapter;
    private ArrayAdapter adaptere;
    private Button button;
    ArrayList<String> listStops;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_stop);
        lv = (ListView) findViewById(R.id.lv);
        //initList();
        EditText theFilter = (EditText) findViewById(R.id.search);

// button to get to Main i.e. departures
        button = (Button) findViewById(R.id.departures);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity();
            }
        });
//make adapter
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, stops);
        lv.setAdapter(adapter);






//listener
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TextView chosen_stop = (TextView)findViewById(R.id.chosen_stop);
                chosen_stop.setText(stops[position]);
            }
        });



    }
    public void openActivity(){
        TextView viewText1 = (TextView) findViewById(R.id.chosen_stop);
        String text = viewText1.getText().toString();
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra(EXTRA_TEXT, text);
        startActivity(intent);

    }



    }